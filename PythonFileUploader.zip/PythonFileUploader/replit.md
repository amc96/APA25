# Aplicativo de Análise de Parentesco - GRASPE

## Overview

This is a web application for analyzing kinship relationships between animals using the GRASPE (Genetic Relationship Analysis for Strategic Pairing Enhancement) method. The system converts CSV files containing animal relationship data into matrices and performs genetic analysis to find optimal breeding pairs through multiple algorithm executions with randomized parameters.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: HTML templates with Bootstrap 5 CSS framework
- **Template Engine**: Jinja2 (Flask's default)
- **UI Components**: 
  - File upload interface with drag-and-drop styling
  - Interactive charts using Chart.js
  - Bootstrap-based responsive design
  - Results visualization with color-coded quality indicators

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Structure**: Single-file application with modular helper functions
- **Request Handling**: Form-based file uploads with security validation
- **File Processing**: CSV to matrix conversion with pandas
- **Algorithm**: GRASPE genetic analysis with multiple execution support

### Data Processing Pipeline
1. CSV file upload and validation
2. Matrix conversion using pandas
3. GRASPE algorithm execution with randomized parameters
4. Results aggregation and statistical analysis
5. Visualization and download generation

## Key Components

### Core Files
- **main.py**: Entry point with application initialization and error handling
- **app.py**: Flask application with route definitions and request handling
- **csv_to_matrix.py**: CSV to matrix conversion utilities
- **graspe.py**: GRASPE algorithm implementation with optimization logic
- **templates/**: HTML templates for user interface

### Algorithm Components
- **GRASPE Algorithm**: Genetic relationship analysis with RCL (Restricted Candidate List) adaptation
- **Multi-execution System**: Runs multiple algorithm instances with random parameters
- **Statistical Analysis**: Calculates means, best/worst solutions, and quality metrics
- **Optimization**: Minimizes coefficient sums for optimal breeding pairs

### Data Models
- **Matrix Structure**: Animals as rows/columns with coefficient values
- **Solution Format**: List of breeding pairs with quality scores
- **Statistics**: Execution results with performance metrics

## Data Flow

1. **Upload Phase**: User uploads CSV file via web interface
2. **Validation**: System validates file format and required columns (Animal_1, Animal_2, Coef)
3. **Conversion**: CSV data converted to relationship matrix
4. **Analysis**: GRASPE algorithm runs multiple times with randomized parameters
5. **Aggregation**: Results combined and statistical analysis performed
6. **Visualization**: Charts and tables generated for results display
7. **Export**: Results available for download in CSV format

## External Dependencies

### Python Packages
- **Flask**: Web framework for HTTP handling and templating
- **pandas**: Data manipulation and CSV processing
- **numpy**: Numerical computations for matrix operations
- **werkzeug**: WSGI utilities and secure filename handling

### Frontend Libraries
- **Bootstrap 5**: CSS framework for responsive design
- **Chart.js**: JavaScript charting library for data visualization
- **Bootstrap Icons**: Icon library for UI elements

### File Dependencies
- **CSV Input**: Requires structured CSV files with animal relationship data
- **Upload Directory**: Local file system for temporary file storage

## Deployment Strategy

### Local Development
- **Startup Scripts**: Platform-specific scripts (iniciar.bat for Windows, iniciar.sh for Linux/Mac)
- **Port Configuration**: Default port 5000 with environment variable override
- **Debug Mode**: Enabled for development with auto-reload

### File Structure
- **uploads/**: Directory for user-uploaded files
- **templates/**: HTML templates for web interface
- **Static Assets**: CSS and JavaScript served via CDN

### Security Considerations
- **File Upload Limits**: 10MB maximum file size
- **File Type Validation**: Only CSV files allowed
- **Secure Filenames**: Werkzeug's secure_filename for path security
- **Input Validation**: CSV structure validation before processing

### Error Handling
- **Graceful Degradation**: User-friendly error messages
- **Import Error Handling**: Dependency checking with helpful error messages
- **File Processing Errors**: Validation and user feedback for malformed data

### Performance Optimizations
- **Multiple Executions**: Configurable number of algorithm runs
- **Randomized Parameters**: Automatic parameter variation for better results
- **Memory Management**: Efficient matrix operations with pandas
- **Result Caching**: Processed results stored for download