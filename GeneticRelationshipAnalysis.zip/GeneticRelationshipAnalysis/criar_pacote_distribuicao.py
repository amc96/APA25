#!/usr/bin/env python3
"""
Script para criar pacote de distribuição completo
"""

import os
import shutil
import zipfile
from datetime import datetime

def criar_pacote_distribuicao():
    """Criar pacote ZIP para distribuição"""
    nome_pacote = f"SistemaAcasalamentoAnimal_v1.0_{datetime.now().strftime('%Y%m%d')}"
    pasta_temp = f"temp_{nome_pacote}"
    
    print("📦 Criando pacote de distribuição...")
    
    # Criar pasta temporária
    if os.path.exists(pasta_temp):
        shutil.rmtree(pasta_temp)
    os.makedirs(pasta_temp)
    
    # Arquivos principais do sistema
    arquivos_sistema = [
        'app.py',
        'csv_to_matrix_original.py', 
        'grasp_original.py',
        'executavel_simples.py',
        'instalar_dependencias.py'
    ]
    
    # Arquivos de execução
    arquivos_execucao = [
        'EXECUTAR_SISTEMA.bat',
        'EXECUTAR_SISTEMA.sh',
        'LEIA_ME_PRIMEIRO.txt'
    ]
    
    # Arquivos de exemplo
    arquivos_exemplo = [
        'attached_assets/parentesco_produtos (1)_1752294659945.csv'
    ]
    
    # Copiar arquivos principais
    print("📁 Copiando arquivos do sistema...")
    for arquivo in arquivos_sistema:
        if os.path.exists(arquivo):
            shutil.copy2(arquivo, pasta_temp)
            print(f"   ✅ {arquivo}")
        else:
            print(f"   ❌ {arquivo} - não encontrado")
    
    # Copiar arquivos de execução
    print("🚀 Copiando arquivos de execução...")
    for arquivo in arquivos_execucao:
        if os.path.exists(arquivo):
            shutil.copy2(arquivo, pasta_temp)
            print(f"   ✅ {arquivo}")
    
    # Criar pasta de exemplos
    pasta_exemplos = os.path.join(pasta_temp, 'exemplos')
    os.makedirs(pasta_exemplos, exist_ok=True)
    
    print("📋 Copiando arquivos de exemplo...")
    for arquivo in arquivos_exemplo:
        if os.path.exists(arquivo):
            nome_arquivo = os.path.basename(arquivo)
            destino = os.path.join(pasta_exemplos, f"exemplo_{nome_arquivo}")
            shutil.copy2(arquivo, destino)
            print(f"   ✅ {nome_arquivo}")
    
    # Criar arquivo ZIP
    nome_zip = f"{nome_pacote}.zip"
    print(f"🗜️ Criando arquivo ZIP: {nome_zip}")
    
    with zipfile.ZipFile(nome_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(pasta_temp):
            for file in files:
                arquivo_completo = os.path.join(root, file)
                arquivo_relativo = os.path.relpath(arquivo_completo, pasta_temp)
                zipf.write(arquivo_completo, arquivo_relativo)
                print(f"   📦 {arquivo_relativo}")
    
    # Limpar pasta temporária
    shutil.rmtree(pasta_temp)
    
    # Verificar tamanho do ZIP
    tamanho_mb = os.path.getsize(nome_zip) / (1024 * 1024)
    
    print("\n🎉 PACOTE CRIADO COM SUCESSO!")
    print(f"📁 Arquivo: {nome_zip}")
    print(f"📊 Tamanho: {tamanho_mb:.1f} MB")
    print(f"📂 Localização: {os.path.abspath(nome_zip)}")
    
    return nome_zip

def criar_instrucoes_instalacao():
    """Criar arquivo de instruções de instalação"""
    instrucoes = """
# INSTRUÇÕES DE INSTALAÇÃO E USO
===============================

## 1. DESCOMPACTAR O ARQUIVO
   - Extraia todos os arquivos para uma pasta
   - Mantenha a estrutura de pastas

## 2. INSTALAÇÃO (primeira vez)
   
   OPÇÃO A - Automática:
   - Windows: Execute "instalar_dependencias.py"
   - Linux/Mac: python3 instalar_dependencias.py
   
   OPÇÃO B - Manual:
   - pip install streamlit pandas numpy plotly matplotlib

## 3. EXECUÇÃO
   
   - Windows: Clique em "EXECUTAR_SISTEMA.bat"
   - Linux/Mac: Execute "./EXECUTAR_SISTEMA.sh"
   - Manual: python executavel_simples.py

## 4. USO
   
   1. Navegador abrirá automaticamente
   2. Carregue seu arquivo CSV
   3. Configure parâmetros
   4. Execute otimização
   5. Visualize resultados
   6. Faça downloads se necessário

## ARQUIVO DE EXEMPLO INCLUÍDO
   
   - Pasta "exemplos" contém arquivo CSV de teste
   - Use para testar o sistema

## SUPORTE
   
   - Leia "LEIA_ME_PRIMEIRO.txt" para detalhes completos
   - Formato CSV: Animal_1, Animal_2, Coef
   - Python 3.7+ necessário
"""
    
    with open('INSTALACAO_E_USO.txt', 'w', encoding='utf-8') as f:
        f.write(instrucoes)
    
    print("📋 Instruções de instalação criadas: INSTALACAO_E_USO.txt")

def main():
    """Função principal"""
    print("=" * 60)
    print("📦 CRIADOR DE PACOTE DE DISTRIBUIÇÃO")
    print("=" * 60)
    
    criar_instrucoes_instalacao()
    nome_arquivo = criar_pacote_distribuicao()
    
    print("\n" + "=" * 60)
    print("✅ PACOTE PRONTO PARA DISTRIBUIÇÃO!")
    print("=" * 60)
    print(f"📁 Envie o arquivo: {nome_arquivo}")
    print("🎯 O usuário só precisa descompactar e executar")

if __name__ == "__main__":
    main()