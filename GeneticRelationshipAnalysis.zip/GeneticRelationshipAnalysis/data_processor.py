import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Any
import re

class DataProcessor:
    """Class to process and manage animal breeding data"""
    
    def __init__(self):
        self.original_data = None
        self.females = []
        self.males = []
        self.female_mapping = {}
        self.male_mapping = {}
        self.coancestry_matrix = None
        self.coef_stats = {}
        self.processed_data = None
        self.unique_females = []
        self.unique_males = []
        
    def load_data(self, uploaded_file) -> pd.DataFrame:
        """Load data from uploaded CSV file"""
        try:
            df = pd.read_csv(uploaded_file)
            
            # Validate required columns
            required_columns = ['Animal_1', 'Animal_2', 'Coef']
            if not all(col in df.columns for col in required_columns):
                raise ValueError(f"CSV deve conter as colunas: {required_columns}")
            
            # Remove any rows with missing values
            df = df.dropna()
            
            # Ensure Coef is numeric
            df['Coef'] = pd.to_numeric(df['Coef'], errors='coerce')
            df = df.dropna()
            
            self.original_data = df.copy()
            return df
            
        except Exception as e:
            raise Exception(f"Erro ao carregar dados: {str(e)}")
    
    def process_data(self, df: pd.DataFrame):
        """Process the loaded data to extract animals and create mappings"""
        
        # Extract unique animals from both columns following PDF format
        # The CSV format shows pairs like "3925318_3926180" which represent offspring
        # We need to extract unique individuals from these pairs
        all_animals = set(df['Animal_1'].unique()) | set(df['Animal_2'].unique())
        
        # Separate females and males based on the animal ID format
        # Assuming format is "femaleID_maleID" based on the data structure
        females_set = set()
        males_set = set()
        
        for animal_pair in all_animals:
            # Split the animal pair to get individual animals
            if '_' in animal_pair:
                female_id, male_id = animal_pair.split('_', 1)
                females_set.add(female_id)
                males_set.add(male_id)
        
        # Convert to sorted lists for consistent ordering
        self.unique_females = sorted(list(females_set))
        self.unique_males = sorted(list(males_set))
        self.females = self.unique_females  # Keep compatibility
        self.males = self.unique_males      # Keep compatibility
        
        # Create mappings from original IDs to F1, F2, M1, M2 format as per PDF
        self.female_mapping = {female: f"F{i+1}" for i, female in enumerate(self.unique_females)}
        self.male_mapping = {male: f"M{i+1}" for i, male in enumerate(self.unique_males)}
        
        # Calculate basic statistics from coefficients
        self.coef_stats = {
            'min': float(df['Coef'].min()),
            'max': float(df['Coef'].max()),
            'mean': float(df['Coef'].mean()),
            'std': float(df['Coef'].std()),
            'count': len(df)
        }
        
        print(f"Processados: {len(self.unique_females)} fêmeas distintas, {len(self.unique_males)} machos distintos")
        print(f"Estatísticas dos coeficientes - Min: {self.coef_stats['min']:.6f}, Max: {self.coef_stats['max']:.6f}, Média: {self.coef_stats['mean']:.6f}")
        
        # Create coancestry matrix following GRASP paper format
        self._create_coancestry_matrix(df)
        
        # Create processed data with renamed animals
        self._create_processed_data(df)
    
    def _create_coancestry_matrix(self, df: pd.DataFrame):
        """Create the coancestry matrix exactly as specified in PDF Definição 1
        
        Following the mathematical definition:
        - Matrix dimensions: (|F| × |M|) × (|F| × |M|)
        - Each row/column represents a possible breeding pair (fi, mj)
        - Matrix element (i,j) contains coancestry between offspring of two different pairs
        """
        num_females = len(self.unique_females)
        num_males = len(self.unique_males)
        
        # Create all possible breeding pairs (F × M)
        breeding_pairs = []
        pair_to_index = {}
        
        index = 0
        for f_idx, female in enumerate(self.unique_females):
            for m_idx, male in enumerate(self.unique_males):
                pair = f"{female}_{male}"
                breeding_pairs.append(pair)
                pair_to_index[pair] = index
                index += 1
        
        matrix_size = len(breeding_pairs)  # |F| × |M|
        
        # Initialize coancestry matrix as specified in PDF
        coancestry_data = np.zeros((matrix_size, matrix_size))
        
        # Fill matrix with coancestry values from CSV
        for _, row in df.iterrows():
            animal1 = row['Animal_1']  # offspring from pair (fi, mj)
            animal2 = row['Animal_2']  # offspring from pair (fk, ml)
            coef = float(row['Coef'])
            
            # Get matrix indices for both breeding pairs
            if animal1 in pair_to_index and animal2 in pair_to_index:
                idx1 = pair_to_index[animal1]
                idx2 = pair_to_index[animal2]
                
                # Fill symmetric matrix
                coancestry_data[idx1, idx2] = coef
                coancestry_data[idx2, idx1] = coef
        
        # Store full coancestry matrix for optimization algorithm
        self.full_coancestry_matrix = coancestry_data
        self.breeding_pairs = breeding_pairs
        self.pair_to_index = pair_to_index
        
        # Also create simplified matrix for GRASP algorithm (Female × Male format)
        # This represents the "cost" of each individual breeding decision
        simple_matrix = np.zeros((num_females, num_males))
        
        # Fill simplified matrix with representative costs
        for f_idx, female in enumerate(self.unique_females):
            for m_idx, male in enumerate(self.unique_males):
                pair = f"{female}_{male}"
                if pair in pair_to_index:
                    # Use average coancestry with all other possible pairs as cost
                    pair_idx = pair_to_index[pair]
                    costs = coancestry_data[pair_idx, :]
                    simple_matrix[f_idx, m_idx] = np.mean(costs[costs > 0]) if np.any(costs > 0) else 0.0
        
        # Create DataFrame for GRASP algorithm compatibility
        self.coancestry_matrix = pd.DataFrame(
            simple_matrix,
            index=[f"F{i+1}" for i in range(num_females)],
            columns=[f"M{i+1}" for i in range(num_males)]
        )
        
        print(f"Matriz de coancestralidade criada: {matrix_size}x{matrix_size} (pares possíveis)")
        print(f"Matriz simplificada para GRASP: {num_females}x{num_males} (fêmeas x machos)")
    
    def _create_processed_data(self, df: pd.DataFrame):
        """Create processed data with renamed animals"""
        processed_rows = []
        
        for _, row in df.iterrows():
            animal1 = row['Animal_1']
            animal2 = row['Animal_2']
            coef = row['Coef']
            
            # Parse animal1
            if '_' in animal1:
                female1, male1 = animal1.split('_', 1)
                animal1_renamed = f"{self.female_mapping.get(female1, female1)}_{self.male_mapping.get(male1, male1)}"
            else:
                animal1_renamed = animal1
            
            # Parse animal2
            if '_' in animal2:
                female2, male2 = animal2.split('_', 1)
                animal2_renamed = f"{self.female_mapping.get(female2, female2)}_{self.male_mapping.get(male2, male2)}"
            else:
                animal2_renamed = animal2
            
            processed_rows.append({
                'Animal_1_Original': animal1,
                'Animal_2_Original': animal2,
                'Animal_1_Renamed': animal1_renamed,
                'Animal_2_Renamed': animal2_renamed,
                'Coef': coef
            })
        
        self.processed_data = pd.DataFrame(processed_rows)
    
    def get_sample_data(self, n=10) -> pd.DataFrame:
        """Get a sample of processed data for display"""
        if self.processed_data is None:
            return pd.DataFrame()
        
        return self.processed_data.head(n)
    
    def get_processed_data_csv(self) -> str:
        """Get processed data as CSV string for download"""
        if self.processed_data is None:
            return ""
        
        return self.processed_data.to_csv(index=False)
    
    def format_solution(self, solution: List[int]) -> pd.DataFrame:
        """Format the optimization solution for display"""
        if not solution:
            return pd.DataFrame()
        
        solution_data = []
        for i, male_idx in enumerate(solution):
            female_name = f"F{i+1}"
            male_name = f"M{male_idx+1}"
            female_original = self.females[i] if i < len(self.females) else f"Female_{i+1}"
            male_original = self.males[male_idx] if male_idx < len(self.males) else f"Male_{male_idx+1}"
            
            solution_data.append({
                'Fêmea': female_name,
                'Macho': male_name,
                'Fêmea_Original': female_original,
                'Macho_Original': male_original
            })
        
        return pd.DataFrame(solution_data)
    
    @property
    def num_females(self) -> int:
        """Get number of unique females"""
        return len(self.females)
    
    @property
    def num_males(self) -> int:
        """Get number of unique males"""
        return len(self.males)
