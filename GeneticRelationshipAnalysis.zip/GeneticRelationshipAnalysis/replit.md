# Sistema de Otimização de Acasalamento Animal

## Overview

This project is a Streamlit-based web application for optimizing animal breeding by minimizing coancestry using the GRASP (Greedy Randomized Adaptive Search Procedure) meta-heuristic algorithm. The system processes coancestry coefficient data from CSV files and provides optimized breeding pair recommendations through an interactive web interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (July 12, 2025)

✓ Implementação completa de sistema único com todas as funcionalidades
✓ Interface integrada mostrando todos os resultados em uma única tela
✓ Renomeação automática para F1, F2, M1, M2...
✓ Gráficos de barras comparativos (entrada vs saída)
✓ Downloads de todos os dados processados
✓ Automação configurável de múltiplas execuções
✓ Integração com algoritmo GRASPE original
✓ Relatório resumo final completo

## System Architecture

The application follows a modular Python architecture with a Streamlit frontend, built around three core components that handle data processing, optimization algorithms, and visualizations. The system is designed as a standalone web application that processes CSV input files and provides real-time optimization results.

### Architecture Pattern
- **Frontend**: Streamlit web application providing an interactive user interface
- **Processing Layer**: Modular Python classes for data processing and optimization
- **Visualization Layer**: Plotly-based interactive charts and graphs
- **Data Flow**: File upload → Processing → Optimization → Visualization → Results

## Key Components

### 1. Streamlit Frontend (app.py)
- **Purpose**: Main application entry point and user interface
- **Responsibilities**: File upload handling, parameter configuration, results display
- **Key Features**: 
  - CSV file upload with validation
  - Interactive sidebar for parameter configuration
  - Multi-column layout for statistics display
  - Progress indicators and status messages

### 2. Data Processor (data_processor.py)
- **Purpose**: Data loading, validation, and preprocessing
- **Responsibilities**: 
  - CSV file parsing and validation
  - Animal identification and classification (male/female separation)
  - Coancestry matrix creation and mapping
  - Data statistics calculation
- **Key Features**: Error handling, data type validation, missing value management

### 3. GRASP Optimizer (grasp_optimizer.py)
- **Purpose**: Core optimization algorithm implementation
- **Algorithm**: GRASP (Greedy Randomized Adaptive Search Procedure)
- **Phases**: 
  - Greedy Randomized Construction
  - Local Search optimization
- **Parameters**: Alpha (randomization factor), max iterations
- **Output**: Optimized breeding pair assignments with cost metrics

### 4. Visualizations (visualizations.py)
- **Purpose**: Interactive data visualization and results presentation
- **Charts**: 
  - Statistics comparison (original vs optimized)
  - Convergence analysis plots
- **Technology**: Plotly for interactive visualizations

## Data Flow

1. **Input**: User uploads CSV file with columns (Animal_1, Animal_2, Coef)
2. **Validation**: Data processor validates file format and required columns
3. **Processing**: Animals are classified and coancestry matrix is constructed
4. **Optimization**: GRASP algorithm minimizes total coancestry
5. **Visualization**: Results are displayed through interactive charts
6. **Output**: Optimized breeding recommendations and performance metrics

## External Dependencies

### Core Libraries
- **streamlit**: Web application framework
- **pandas**: Data manipulation and analysis
- **numpy**: Numerical computing and matrix operations
- **matplotlib**: Static plotting (legacy support)
- **plotly**: Interactive visualizations

### File Handling
- **io**: String and byte stream handling for file uploads
- **json**: JSON data serialization (potential configuration storage)

### Optimization
- **random**: Randomization for GRASP algorithm
- **copy**: Deep copying for solution manipulation
- **time**: Performance timing and progress tracking

## Deployment Strategy

The application is designed for single-file deployment as a Streamlit web application. Key deployment considerations:

### Local Development
- Run using `streamlit run app.py`
- No database required - processes uploaded files in memory
- All dependencies managed through pip/conda

### Production Considerations
- Stateless design suitable for containerization
- Memory usage scales with input file size
- No persistent storage requirements
- Can be deployed on platforms supporting Python/Streamlit (Streamlit Cloud, Heroku, etc.)

### Configuration
- Parameters configurable through Streamlit sidebar
- No external configuration files required
- All settings managed through the web interface

## Technical Architecture Decisions

### Why Streamlit?
- **Problem**: Need for rapid development of an interactive web interface
- **Solution**: Streamlit provides Python-native web app development
- **Pros**: Fast development, built-in components, Python ecosystem integration
- **Cons**: Limited customization compared to traditional web frameworks

### Why GRASP Algorithm?
- **Problem**: Complex combinatorial optimization for breeding pairs
- **Solution**: GRASP provides good balance between solution quality and computation time
- **Pros**: Handles large solution spaces, provides near-optimal solutions
- **Cons**: May not guarantee global optimum

### Why Plotly for Visualizations?
- **Problem**: Need for interactive data exploration and results presentation
- **Solution**: Plotly provides rich interactive visualizations
- **Pros**: Interactive features, professional appearance, Streamlit integration
- **Cons**: Larger library size compared to matplotlib

### Data Processing Architecture
- **Problem**: Need to handle various CSV formats and validate data integrity
- **Solution**: Dedicated DataProcessor class with validation and error handling
- **Pros**: Modular design, robust error handling, extensible for new data formats
- **Cons**: Additional complexity for simple use cases