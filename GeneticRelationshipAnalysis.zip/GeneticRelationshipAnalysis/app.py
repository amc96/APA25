import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from io import StringIO, BytesIO
import os
import tempfile
import time
from csv_to_matrix_original import csv_to_matrix, get_matrix_statistics, contagem_animais
from grasp_original import grasp_multiplas_execucoes

def main():
    st.set_page_config(
        page_title="Sistema de Otimização de Acasalamento Animal - GRASPE",
        page_icon="🐄",
        layout="wide"
    )
    
    st.title("🐄 Sistema de Otimização de Acasalamento Animal")
    st.markdown("### Minimização de Coancestralidade usando Meta-heurística GRASPE")
    st.markdown("---")
    
    # Upload do arquivo
    st.header("📂 1. Upload do Arquivo CSV")
    uploaded_file = st.file_uploader(
        "Escolha o arquivo CSV com dados de coancestralidade",
        type=['csv'],
        help="Arquivo deve conter colunas: Animal_1, Animal_2, Coef"
    )
    
    if uploaded_file is not None:
        # Salvar arquivo temporariamente
        with tempfile.NamedTemporaryFile(delete=False, suffix='.csv', mode='wb') as tmp_file:
            tmp_file.write(uploaded_file.getvalue())
            tmp_path = tmp_file.name
        
        try:
            # Processar dados
            df_original = pd.read_csv(tmp_path)
            contagem = contagem_animais(tmp_path)
            matriz_original = csv_to_matrix(tmp_path)
            
            # SEÇÃO 1: ANÁLISE DOS DADOS DE ENTRADA
            st.header("📊 2. Análise dos Dados de Entrada")
            
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("📊 Total de Registros", len(df_original))
            
            with col2:
                st.metric("♀️ Fêmeas Distintas", contagem['animais_1_distintos'])
            
            with col3:
                st.metric("♂️ Machos Distintos", contagem['animais_2_distintos'])
            
            with col4:
                st.metric("🔢 Total Animais Únicos", contagem['total_animais_distintos'])
            
            # Estatísticas dos coeficientes de entrada
            coef_stats = {
                'min': df_original['Coef'].min(),
                'max': df_original['Coef'].max(),
                'mean': df_original['Coef'].mean(),
                'std': df_original['Coef'].std()
            }
            
            st.subheader("📈 Estatísticas dos Coeficientes de Entrada")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("📉 Coeficiente Mínimo", f"{coef_stats['min']:.6f}")
            
            with col2:
                st.metric("📈 Coeficiente Máximo", f"{coef_stats['max']:.6f}")
            
            with col3:
                st.metric("📊 Coeficiente Médio", f"{coef_stats['mean']:.6f}")
            
            # Gráfico de barras dos coeficientes de entrada
            st.subheader("📊 Gráfico de Barras - Estatísticas de Entrada")
            
            fig_entrada = go.Figure(data=[
                go.Bar(
                    x=['Mínimo', 'Máximo', 'Média'],
                    y=[coef_stats['min'], coef_stats['max'], coef_stats['mean']],
                    marker_color=['green', 'red', 'blue'],
                    text=[f"{coef_stats['min']:.6f}", f"{coef_stats['max']:.6f}", f"{coef_stats['mean']:.6f}"],
                    textposition='auto'
                )
            ])
            
            fig_entrada.update_layout(
                title="Estatísticas dos Coeficientes de Entrada",
                xaxis_title="Estatística",
                yaxis_title="Valor do Coeficiente",
                template='plotly_white'
            )
            
            st.plotly_chart(fig_entrada, use_container_width=True)
            
            # SEÇÃO 2: MATRIZ GERADA
            st.header("🔢 3. Matriz Gerada com Dados de Entrada")
            
            st.write(f"**Dimensões da Matriz:** {matriz_original.shape[0]} x {matriz_original.shape[1]}")
            
            # Mostrar amostra da matriz original
            st.subheader("Amostra da Matriz Original (10x10)")
            matrix_sample = matriz_original.iloc[:min(10, matriz_original.shape[0]), :min(10, matriz_original.shape[1])]
            st.dataframe(matrix_sample, use_container_width=True)
            
            # SEÇÃO 3: RENOMEAÇÃO F1, F2, M1, M2
            st.header("🏷️ 4. Renomeação de Animais (F1, F2, M1, M2...)")
            
            # Criar mapeamento de renomeação
            femeas_originais = contagem['lista_animais_1']
            machos_originais = contagem['lista_animais_2']
            
            # Criar matriz renomeada
            matriz_renomeada = matriz_original.copy()
            
            # Renomear índices (fêmeas)
            novo_index = [f"F{i+1}" for i in range(len(femeas_originais))]
            matriz_renomeada.index = novo_index
            
            # Renomear colunas (machos)
            novo_columns = [f"M{i+1}" for i in range(len(machos_originais))]
            matriz_renomeada.columns = novo_columns
            
            # Criar mapeamento para referência
            mapeamento_femeas = {f"F{i+1}": femeas_originais[i] for i in range(len(femeas_originais))}
            mapeamento_machos = {f"M{i+1}": machos_originais[i] for i in range(len(machos_originais))}
            
            st.subheader("Mapeamento de Nomes")
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Fêmeas (primeiras 10):**")
                for i, (novo, original) in enumerate(list(mapeamento_femeas.items())[:10]):
                    st.write(f"{novo}: {original}")
                if len(mapeamento_femeas) > 10:
                    st.write(f"... e mais {len(mapeamento_femeas) - 10}")
            
            with col2:
                st.write("**Machos (primeiros 10):**")
                for i, (novo, original) in enumerate(list(mapeamento_machos.items())[:10]):
                    st.write(f"{novo}: {original}")
                if len(mapeamento_machos) > 10:
                    st.write(f"... e mais {len(mapeamento_machos) - 10}")
            
            # Mostrar amostra da matriz renomeada
            st.subheader("Amostra da Matriz Renomeada (10x10)")
            matrix_renamed_sample = matriz_renomeada.iloc[:min(10, matriz_renomeada.shape[0]), :min(10, matriz_renomeada.shape[1])]
            st.dataframe(matrix_renamed_sample, use_container_width=True)
            
            # SEÇÃO 4: PARÂMETROS GRASPE
            st.header("⚙️ 5. Configuração da Meta-heurística GRASPE")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                num_execucoes = st.number_input(
                    "Número de Execuções", 
                    min_value=1, 
                    max_value=50, 
                    value=5,
                    help="Quantas vezes executar o algoritmo GRASPE"
                )
            
            with col2:
                iteracoes_por_execucao = st.number_input(
                    "Iterações por Execução", 
                    min_value=10, 
                    max_value=500, 
                    value=100
                )
            
            with col3:
                rcl_alpha = st.slider(
                    "Parâmetro Alpha (RCL)", 
                    min_value=0.1, 
                    max_value=0.9, 
                    value=0.3,
                    help="Controla a aleatoriedade na construção da solução"
                )
            
            # Botão para executar otimização
            if st.button("🚀 Executar Otimização GRASPE", type="primary", use_container_width=True):
                
                # SEÇÃO 5: EXECUÇÃO DA OTIMIZAÇÃO
                st.header("🔄 6. Execução da Otimização GRASPE")
                
                with st.spinner(f"Executando {num_execucoes} execuções do algoritmo GRASPE..."):
                    inicio_tempo = time.time()
                    
                    # Executar GRASPE usando implementação original
                    resultado_multiplo = grasp_multiplas_execucoes(
                        matriz_renomeada, 
                        num_execucoes,
                        verbose=False
                    )
                    
                    tempo_total = time.time() - inicio_tempo
                
                # Extrair resultados
                melhor_solucao_global = resultado_multiplo['melhor_solucao_global']
                estatisticas_multiplas = resultado_multiplo['estatisticas']
                todas_execucoes = resultado_multiplo['execucoes']
                
                # SEÇÃO 6: RESULTADOS DA OTIMIZAÇÃO
                st.header("🎯 7. Resultados da Otimização")
                
                # Estatísticas de saída
                coef_saida_stats = {
                    'min': estatisticas_multiplas['melhor_media'],
                    'max': max(estatisticas_multiplas['todas_medias']),
                    'mean': estatisticas_multiplas['media_das_medias']
                }
                
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric("🏆 Melhor Custo", f"{melhor_solucao_global['valor_objetivo']:.6f}")
                
                with col2:
                    st.metric("📊 Custo Médio", f"{coef_saida_stats['mean']:.6f}")
                
                with col3:
                    melhoria = ((coef_stats['mean'] - melhor_solucao_global['valor_objetivo']) / coef_stats['mean'] * 100)
                    st.metric("📈 Melhoria (%)", f"{melhoria:.2f}%")
                
                with col4:
                    st.metric("⏱️ Tempo Total", f"{tempo_total:.2f}s")
                
                # Estatísticas de saída detalhadas
                st.subheader("📈 Estatísticas dos Coeficientes de Saída")
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("📉 Coeficiente Mínimo", f"{coef_saida_stats['min']:.6f}")
                
                with col2:
                    st.metric("📈 Coeficiente Máximo", f"{coef_saida_stats['max']:.6f}")
                
                with col3:
                    st.metric("📊 Coeficiente Médio", f"{coef_saida_stats['mean']:.6f}")
                
                # SEÇÃO 7: GRÁFICOS DE COMPARAÇÃO
                st.header("📊 8. Gráficos de Comparação - Entrada vs Saída")
                
                # Gráfico de barras comparativo
                fig_comparacao = go.Figure(data=[
                    go.Bar(
                        name='Entrada',
                        x=['Mínimo', 'Máximo', 'Média'],
                        y=[coef_stats['min'], coef_stats['max'], coef_stats['mean']],
                        marker_color='lightcoral',
                        text=[f"{coef_stats['min']:.6f}", f"{coef_stats['max']:.6f}", f"{coef_stats['mean']:.6f}"],
                        textposition='auto'
                    ),
                    go.Bar(
                        name='Saída Otimizada',
                        x=['Mínimo', 'Máximo', 'Média'],
                        y=[coef_saida_stats['min'], coef_saida_stats['max'], coef_saida_stats['mean']],
                        marker_color='lightblue',
                        text=[f"{coef_saida_stats['min']:.6f}", f"{coef_saida_stats['max']:.6f}", f"{coef_saida_stats['mean']:.6f}"],
                        textposition='auto'
                    )
                ])
                
                fig_comparacao.update_layout(
                    title="Comparação: Estatísticas de Entrada vs Saída Otimizada",
                    xaxis_title="Estatística",
                    yaxis_title="Valor do Coeficiente",
                    barmode='group',
                    template='plotly_white'
                )
                
                st.plotly_chart(fig_comparacao, use_container_width=True)
                
                # SEÇÃO 8: MELHOR SOLUÇÃO ENCONTRADA
                st.header("🏆 9. Melhor Solução Encontrada")
                
                if melhor_solucao_global['cruzamentos']:
                    solution_data = []
                    for cruzamento in melhor_solucao_global['cruzamentos']:
                        female_name = cruzamento['Animal_1']
                        male_name = cruzamento['Animal_2']
                        
                        # Recuperar nomes originais
                        female_original = mapeamento_femeas.get(female_name, female_name)
                        male_original = mapeamento_machos.get(male_name, male_name)
                        
                        solution_data.append({
                            'Fêmea_Código': female_name,
                            'Macho_Código': male_name,
                            'Fêmea_Original': female_original,
                            'Macho_Original': male_original,
                            'Coeficiente': cruzamento['Coeficiente']
                        })
                    
                    solucao_df = pd.DataFrame(solution_data)
                    st.dataframe(solucao_df, use_container_width=True)
                    
                    st.write(f"**Total de cruzamentos na melhor solução:** {len(solution_data)}")
                    st.write(f"**Valor objetivo (soma dos coeficientes):** {melhor_solucao_global['valor_objetivo']:.6f}")
                    st.write(f"**Média dos coeficientes:** {melhor_solucao_global['media_coeficientes']:.6f}")
                
                # SEÇÃO 9: ANÁLISE POR EXECUÇÃO
                st.header("📈 10. Análise por Execução")
                
                execucoes_data = []
                for i, execucao in enumerate(todas_execucoes, 1):
                    execucoes_data.append({
                        'Execução': i,
                        'Valor_Objetivo': execucao['valor_objetivo'],
                        'Média_Coeficientes': execucao['media_coeficientes'],
                        'Total_Cruzamentos': execucao['total_cruzamentos'],
                        'Tempo_Execução': execucao['tempo_execucao']
                    })
                
                execucoes_df = pd.DataFrame(execucoes_data)
                st.dataframe(execucoes_df, use_container_width=True)
                
                # Gráfico de evolução por execução
                fig_execucoes = go.Figure()
                fig_execucoes.add_trace(go.Bar(
                    x=execucoes_df['Execução'],
                    y=execucoes_df['Valor_Objetivo'],
                    name='Valor Objetivo',
                    marker_color='skyblue'
                ))
                
                fig_execucoes.update_layout(
                    title="Valor Objetivo por Execução",
                    xaxis_title="Execução",
                    yaxis_title="Valor Objetivo"
                )
                
                st.plotly_chart(fig_execucoes, use_container_width=True)
                
                # SEÇÃO 10: DOWNLOADS
                st.header("💾 11. Downloads dos Resultados")
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    # Download da melhor solução
                    if 'solucao_df' in locals():
                        csv_solucao = solucao_df.to_csv(index=False)
                        st.download_button(
                            label="🏆 Baixar Melhor Solução",
                            data=csv_solucao,
                            file_name="melhor_solucao_graspe.csv",
                            mime="text/csv",
                            use_container_width=True
                        )
                
                with col2:
                    # Download das estatísticas por execução
                    csv_execucoes = execucoes_df.to_csv(index=False)
                    st.download_button(
                        label="📊 Baixar Análise por Execução",
                        data=csv_execucoes,
                        file_name="analise_execucoes_graspe.csv",
                        mime="text/csv",
                        use_container_width=True
                    )
                
                with col3:
                    # Download da matriz renomeada
                    csv_matriz = matriz_renomeada.to_csv()
                    st.download_button(
                        label="🔢 Baixar Matriz Renomeada",
                        data=csv_matriz,
                        file_name="matriz_renomeada.csv",
                        mime="text/csv",
                        use_container_width=True
                    )
                
                # SEÇÃO 11: RELATÓRIO RESUMO
                st.header("📋 12. Relatório Resumo Final")
                
                st.markdown(f"""
                ## Resumo da Otimização GRASPE
                
                ### 📊 Dados de Entrada:
                - **Fêmeas distintas:** {contagem['animais_1_distintos']}
                - **Machos distintos:** {contagem['animais_2_distintos']}
                - **Total de registros:** {len(df_original)}
                - **Coeficiente médio original:** {coef_stats['mean']:.6f}
                - **Coeficiente mínimo original:** {coef_stats['min']:.6f}
                - **Coeficiente máximo original:** {coef_stats['max']:.6f}
                
                ### 🔢 Matriz Gerada:
                - **Dimensões:** {matriz_original.shape[0]} x {matriz_original.shape[1]}
                - **Renomeação:** F1-F{len(femeas_originais)}, M1-M{len(machos_originais)}
                
                ### ⚙️ Parâmetros GRASPE:
                - **Número de execuções:** {num_execucoes}
                - **Iterações por execução:** {iteracoes_por_execucao}
                - **Parâmetro Alpha:** {rcl_alpha}
                
                ### 🎯 Resultados:
                - **Melhor valor objetivo:** {melhor_solucao_global['valor_objetivo']:.6f}
                - **Média das médias:** {coef_saida_stats['mean']:.6f}
                - **Melhoria obtida:** {melhoria:.2f}%
                - **Tempo total:** {tempo_total:.2f} segundos
                - **Total de cruzamentos:** {melhor_solucao_global['total_cruzamentos']}
                
                ### 📈 Estatísticas de Saída:
                - **Coeficiente mínimo:** {coef_saida_stats['min']:.6f}
                - **Coeficiente máximo:** {coef_saida_stats['max']:.6f}
                - **Coeficiente médio:** {coef_saida_stats['mean']:.6f}
                """)
        
        except Exception as e:
            st.error(f"❌ Erro ao processar arquivo: {str(e)}")
            import traceback
            st.error(traceback.format_exc())
        
        finally:
            # Limpar arquivo temporário
            try:
                os.unlink(tmp_path)
            except:
                pass
    
    else:
        st.info("👆 Por favor, carregue um arquivo CSV para começar a análise.")
        
        # Mostrar formato esperado
        st.subheader("📋 Formato Esperado do Arquivo")
        st.code("""
Animal_1,Animal_2,Coef
3925318_3926180,3925318_3927975,0.328125
3925318_3926180,3925318_3929376,0.328125
3925318_3926180,3925318_3929377,0.328125
        """, language="csv")

if __name__ == "__main__":
    main()