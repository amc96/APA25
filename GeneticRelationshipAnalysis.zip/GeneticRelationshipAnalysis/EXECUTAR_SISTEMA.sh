#!/bin/bash

echo "============================================================"
echo "  SISTEMA DE OTIMIZAÇÃO DE ACASALAMENTO ANIMAL - GRASPE"
echo "============================================================"
echo
echo "Iniciando sistema..."
echo

python3 executavel_simples.py

echo
echo "Sistema encerrado."
read -p "Pressione Enter para sair..."