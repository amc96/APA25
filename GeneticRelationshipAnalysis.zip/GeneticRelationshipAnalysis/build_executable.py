#!/usr/bin/env python3
"""
Script para gerar executável do Sistema de Otimização de Acasalamento Animal
"""

import os
import shutil
import subprocess
import sys

def create_spec_file():
    """Criar arquivo .spec personalizado para PyInstaller"""
    spec_content = '''
# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

# Lista de arquivos de dados necessários
datas = [
    ('app.py', '.'),
    ('csv_to_matrix_original.py', '.'),
    ('grasp_original.py', '.'),
    ('attached_assets/parentesco_produtos (1)_1752294659945.csv', 'attached_assets'),
]

# Lista de módulos ocultos necessários
hiddenimports = [
    'streamlit',
    'pandas',
    'numpy',
    'plotly',
    'plotly.graph_objects',
    'plotly.express',
    'altair',
    'streamlit.web.cli',
    'streamlit.runtime.scriptrunner.magic_funcs',
    'streamlit.runtime.caching.cache_data_api',
    'streamlit.runtime.metrics_util',
    'streamlit.components.v1.html',
    'streamlit.components.v1.iframe',
]

a = Analysis(
    ['main_executable.py'],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='SistemaAcasalamentoAnimal',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
)
'''
    
    with open('sistema_acasalamento.spec', 'w', encoding='utf-8') as f:
        f.write(spec_content)
    
    print("✅ Arquivo .spec criado: sistema_acasalamento.spec")

def build_executable():
    """Construir o executável"""
    print("🔨 Iniciando construção do executável...")
    
    try:
        # Limpar diretórios anteriores
        if os.path.exists('build'):
            shutil.rmtree('build')
            print("🗑️ Diretório build limpo")
        
        if os.path.exists('dist'):
            shutil.rmtree('dist')
            print("🗑️ Diretório dist limpo")
        
        # Executar PyInstaller
        cmd = [sys.executable, '-m', 'PyInstaller', '--clean', 'sistema_acasalamento.spec']
        
        print("⚙️ Executando PyInstaller...")
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            print("✅ Executável criado com sucesso!")
            print(f"📁 Localização: {os.path.abspath('dist/SistemaAcasalamentoAnimal')}")
            
            # Verificar se executável foi criado
            if os.name == 'nt':  # Windows
                exe_path = 'dist/SistemaAcasalamentoAnimal.exe'
            else:  # Linux/Mac
                exe_path = 'dist/SistemaAcasalamentoAnimal'
            
            if os.path.exists(exe_path):
                file_size = os.path.getsize(exe_path) / (1024 * 1024)  # MB
                print(f"📊 Tamanho do executável: {file_size:.1f} MB")
                
                # Criar README para distribuição
                create_distribution_readme()
                
                print("\n🎉 EXECUTÁVEL CRIADO COM SUCESSO!")
                print(f"📂 Execute o arquivo: {exe_path}")
                print("📋 Leia o arquivo README_EXECUTAVEL.txt para instruções")
                
            else:
                print("❌ Executável não encontrado após build")
                
        else:
            print("❌ Erro na criação do executável:")
            print(result.stderr)
            
    except Exception as e:
        print(f"❌ Erro durante build: {e}")

def create_distribution_readme():
    """Criar README para distribuição"""
    readme_content = """
# Sistema de Otimização de Acasalamento Animal - GRASPE

## 🐄 Sobre o Sistema

Este é um sistema completo para otimização de acasalamento animal que utiliza a meta-heurística GRASP (Greedy Randomized Adaptive Search Procedure) para minimizar coancestralidade.

## 🚀 Como Usar

### Windows:
1. Execute o arquivo `SistemaAcasalamentoAnimal.exe`

### Linux/Mac:
1. Torne o arquivo executável: `chmod +x SistemaAcasalamentoAnimal`
2. Execute: `./SistemaAcasalamentoAnimal`

### Após executar:
1. O sistema iniciará automaticamente
2. Seu navegador abrirá em http://localhost:8501
3. Carregue um arquivo CSV com formato: Animal_1, Animal_2, Coef
4. Configure os parâmetros de otimização
5. Execute a análise GRASPE

## 📊 Funcionalidades

✅ Contagem de machos e fêmeas distintos
✅ Estatísticas de entrada (min, max, média)
✅ Geração de matriz de coancestralidade
✅ Renomeação automática (F1, F2, M1, M2...)
✅ Otimização GRASPE com múltiplas execuções
✅ Gráficos comparativos de entrada vs saída
✅ Download de todos os resultados
✅ Relatório completo em uma única tela

## 📋 Formato do Arquivo CSV

Seu arquivo deve conter estas colunas:
- Animal_1: Identificação da fêmea
- Animal_2: Identificação do macho  
- Coef: Coeficiente de coancestralidade

Exemplo:
```
Animal_1,Animal_2,Coef
3925318_3926180,3925318_3927975,0.328125
3925318_3926180,3925318_3929376,0.328125
```

## ⚙️ Parâmetros Configuráveis

- **Número de Execuções**: Quantas vezes executar o algoritmo
- **Iterações por Execução**: Complexidade da busca
- **Parâmetro Alpha**: Controle de aleatoriedade (0.1 a 0.9)

## 🔧 Solução de Problemas

### O executável não inicia:
- Verifique se tem permissão de execução
- Execute como administrador se necessário
- Verifique se o firewall não está bloqueando

### Navegador não abre automaticamente:
- Abra manualmente: http://localhost:8501
- Aguarde alguns segundos para o sistema inicializar

### Erro ao carregar CSV:
- Verifique se o arquivo tem as colunas corretas
- Certifique-se que não há caracteres especiais
- Use codificação UTF-8

## 📞 Suporte

Sistema desenvolvido usando:
- Python + Streamlit (Interface Web)
- Meta-heurística GRASPE original
- Bibliotecas: Pandas, NumPy, Plotly

Para parar o sistema: Pressione Ctrl+C no terminal
"""
    
    with open('README_EXECUTAVEL.txt', 'w', encoding='utf-8') as f:
        f.write(readme_content)
    
    print("📋 README criado: README_EXECUTAVEL.txt")

def main():
    """Função principal"""
    print("=" * 60)
    print("🐄 Construtor de Executável - Sistema Acasalamento Animal")
    print("=" * 60)
    
    # Verificar se PyInstaller está instalado
    try:
        import PyInstaller
        print(f"✅ PyInstaller encontrado: versão {PyInstaller.__version__}")
    except ImportError:
        print("❌ PyInstaller não encontrado. Instalando...")
        subprocess.run([sys.executable, '-m', 'pip', 'install', 'pyinstaller'])
    
    # Criar arquivo .spec
    create_spec_file()
    
    # Construir executável
    build_executable()
    
    print("\n" + "=" * 60)
    print("🎯 Construção concluída!")
    print("=" * 60)

if __name__ == "__main__":
    main()