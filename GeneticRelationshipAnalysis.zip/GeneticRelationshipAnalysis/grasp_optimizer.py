import numpy as np
import pandas as pd
import random
import time
from typing import List, Tuple, Dict, Set
import copy

class GRASPOptimizer:
    """GRASP (Greedy Randomized Adaptive Search Procedure) optimizer for animal breeding
    Based on original GRASPE implementation with adaptations for coancestry minimization"""
    
    def __init__(self, coancestry_matrix: np.ndarray, females: List[str], males: List[str], 
                 alpha: float = 0.3, max_iterations: int = 50):
        """
        Initialize GRASP optimizer following original GRASPE algorithm
        
        Args:
            coancestry_matrix: Matrix with coancestry coefficients  
            females: List of female animals
            males: List of male animals
            alpha: Randomization parameter (RCL size - 0=greedy, 1=random)
            max_iterations: Maximum iterations for local search
        """
        self.coancestry_matrix = coancestry_matrix
        self.females = females
        self.males = males
        self.num_females = len(females)
        self.num_males = len(males)
        self.alpha = alpha  # RCL parameter from original GRASPE
        self.max_iterations = max_iterations
        
        # Create matrix format similar to original csv_to_matrix format
        # Each row represents a female, each column represents a male
        if isinstance(coancestry_matrix, np.ndarray):
            # Convert to DataFrame format expected by original GRASPE
            self.matrix_df = pd.DataFrame(
                coancestry_matrix[:self.num_females, :self.num_males],
                index=[f"F{i+1}" for i in range(self.num_females)],
                columns=[f"M{i+1}" for i in range(self.num_males)]
            )
    
    def run(self) -> Tuple[List[int], float]:
        """
        Run GRASP algorithm
        
        Returns:
            Tuple of (best_solution, best_cost)
        """
        # Phase 1: Greedy Randomized Construction
        solution = self._greedy_randomized_construction()
        
        # Phase 2: Local Search
        solution = self._local_search(solution)
        
        # Calculate final cost
        cost = self._calculate_cost(solution)
        
        return solution, cost
    
    def _greedy_randomized_construction(self) -> List[int]:
        """
        Greedy randomized construction phase of GRASP
        
        Returns:
            Initial solution (list of male indices for each female)
        """
        solution = [-1] * self.num_females
        male_usage = [0] * self.num_males
        max_male_usage = self.num_females // self.num_males + 1
        
        # For each female, select a male
        for female_idx in range(self.num_females):
            # Calculate costs for each available male
            costs = []
            available_males = []
            
            for male_idx in range(self.num_males):
                if male_usage[male_idx] < max_male_usage:
                    cost = self._calculate_incremental_cost(solution, female_idx, male_idx)
                    costs.append(cost)
                    available_males.append(male_idx)
            
            if not available_males:
                # If no males available under constraints, choose any
                available_males = list(range(self.num_males))
                costs = [self._calculate_incremental_cost(solution, female_idx, m) 
                        for m in available_males]
            
            # Create Restricted Candidate List (RCL)
            min_cost = min(costs)
            max_cost = max(costs)
            threshold = min_cost + self.alpha * (max_cost - min_cost)
            
            rcl = [available_males[i] for i, cost in enumerate(costs) if cost <= threshold]
            
            # Randomly select from RCL
            selected_male = random.choice(rcl)
            solution[female_idx] = selected_male
            male_usage[selected_male] += 1
        
        return solution
    
    def _calculate_incremental_cost(self, partial_solution: List[int], 
                                  female_idx: int, male_idx: int) -> float:
        """
        Calculate incremental cost of assigning male_idx to female_idx
        
        Args:
            partial_solution: Current partial solution
            female_idx: Index of female to assign
            male_idx: Index of male to assign
            
        Returns:
            Incremental cost
        """
        cost = 0.0
        
        # Calculate cost with respect to already assigned pairs
        for other_female_idx in range(female_idx):
            if partial_solution[other_female_idx] != -1:
                other_male_idx = partial_solution[other_female_idx]
                
                # Get matrix indices for both pairs
                pair1_idx = self.pair_to_matrix_idx.get((female_idx, male_idx), 0)
                pair2_idx = self.pair_to_matrix_idx.get((other_female_idx, other_male_idx), 0)
                
                # Add coancestry between these two potential offspring
                if pair1_idx < len(self.coancestry_matrix) and pair2_idx < len(self.coancestry_matrix[0]):
                    cost += self.coancestry_matrix[pair1_idx][pair2_idx]
        
        return cost
    
    def _local_search(self, solution: List[int]) -> List[int]:
        """
        Local search phase to improve the solution
        
        Args:
            solution: Initial solution
            
        Returns:
            Improved solution
        """
        current_solution = copy.deepcopy(solution)
        current_cost = self._calculate_cost(current_solution)
        
        improved = True
        iterations = 0
        
        while improved and iterations < self.max_iterations:
            improved = False
            iterations += 1
            
            # Try swapping assignments
            for i in range(self.num_females):
                for j in range(i + 1, self.num_females):
                    # Create neighbor by swapping
                    neighbor = copy.deepcopy(current_solution)
                    neighbor[i], neighbor[j] = neighbor[j], neighbor[i]
                    
                    neighbor_cost = self._calculate_cost(neighbor)
                    
                    if neighbor_cost < current_cost:
                        current_solution = neighbor
                        current_cost = neighbor_cost
                        improved = True
                        break
                
                if improved:
                    break
            
            # Try reassigning each female to a different male
            if not improved:
                for female_idx in range(self.num_females):
                    current_male = current_solution[female_idx]
                    
                    for male_idx in range(self.num_males):
                        if male_idx != current_male:
                            neighbor = copy.deepcopy(current_solution)
                            neighbor[female_idx] = male_idx
                            
                            neighbor_cost = self._calculate_cost(neighbor)
                            
                            if neighbor_cost < current_cost:
                                current_solution = neighbor
                                current_cost = neighbor_cost
                                improved = True
                                break
                    
                    if improved:
                        break
        
        return current_solution
    
    def _calculate_cost(self, solution: List[int]) -> float:
        """
        Calculate total cost of a solution
        
        Args:
            solution: List of male assignments for each female
            
        Returns:
            Total coancestry cost
        """
        total_cost = 0.0
        
        # Sum coancestry between all pairs of offspring
        for i in range(self.num_females):
            for j in range(i + 1, self.num_females):
                male_i = solution[i]
                male_j = solution[j]
                
                # Get matrix indices
                pair_i_idx = self.pair_to_matrix_idx.get((i, male_i), 0)
                pair_j_idx = self.pair_to_matrix_idx.get((j, male_j), 0)
                
                # Add coancestry between offspring i and j
                if (pair_i_idx < len(self.coancestry_matrix) and 
                    pair_j_idx < len(self.coancestry_matrix[0])):
                    total_cost += self.coancestry_matrix[pair_i_idx][pair_j_idx]
        
        return total_cost
    
    def validate_solution(self, solution: List[int]) -> bool:
        """
        Validate if a solution is feasible
        
        Args:
            solution: Solution to validate
            
        Returns:
            True if solution is valid
        """
        if len(solution) != self.num_females:
            return False
        
        for male_idx in solution:
            if male_idx < 0 or male_idx >= self.num_males:
                return False
        
        return True
