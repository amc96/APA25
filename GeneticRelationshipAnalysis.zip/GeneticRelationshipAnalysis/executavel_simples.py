#!/usr/bin/env python3
"""
Sistema de Otimização de Acasalamento Animal - GRASPE
Executável Python simplificado
"""

import os
import sys
import subprocess
import webbrowser
import time
from threading import Thread

def verificar_dependencias():
    """Verificar e instalar dependências necessárias"""
    dependencias = [
        'streamlit',
        'pandas', 
        'numpy',
        'plotly'
    ]
    
    print("🔍 Verificando dependências...")
    
    dependencias_faltando = []
    for dep in dependencias:
        try:
            __import__(dep)
            print(f"✅ {dep}")
        except ImportError:
            dependencias_faltando.append(dep)
            print(f"❌ {dep} - não encontrado")
    
    if dependencias_faltando:
        print(f"\n📦 Instalando dependências faltando: {', '.join(dependencias_faltando)}")
        for dep in dependencias_faltando:
            try:
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', dep])
                print(f"✅ {dep} instalado")
            except subprocess.CalledProcessError:
                print(f"❌ Erro ao instalar {dep}")
                return False
    
    return True

def abrir_navegador():
    """Abrir navegador após delay"""
    print("🌐 Aguardando inicialização do servidor...")
    time.sleep(4)
    
    try:
        webbrowser.open('http://localhost:8501')
        print("✅ Navegador aberto automaticamente")
    except Exception as e:
        print(f"⚠️ Não foi possível abrir navegador automaticamente: {e}")
        print("📱 Abra manualmente: http://localhost:8501")

def executar_streamlit():
    """Executar aplicação Streamlit"""
    # Verificar se arquivo principal existe
    if not os.path.exists('app.py'):
        print("❌ Arquivo app.py não encontrado!")
        print("📁 Certifique-se de estar no diretório correto do projeto")
        return False
    
    # Configurar variáveis de ambiente
    os.environ['STREAMLIT_SERVER_HEADLESS'] = 'true'
    os.environ['STREAMLIT_BROWSER_GATHER_USAGE_STATS'] = 'false'
    
    # Comando para executar Streamlit
    cmd = [
        sys.executable, '-m', 'streamlit', 'run', 
        'app.py',
        '--server.port=8501',
        '--server.address=0.0.0.0',
        '--server.headless=true',
        '--browser.gatherUsageStats=false'
    ]
    
    try:
        print("🚀 Iniciando aplicação Streamlit...")
        subprocess.run(cmd)
    except KeyboardInterrupt:
        print("\n👋 Aplicação encerrada pelo usuário")
    except Exception as e:
        print(f"❌ Erro ao executar aplicação: {e}")
        return False
    
    return True

def main():
    """Função principal"""
    print("=" * 70)
    print("🐄 SISTEMA DE OTIMIZAÇÃO DE ACASALAMENTO ANIMAL - GRASPE")
    print("=" * 70)
    print()
    print("📋 Este sistema oferece:")
    print("   ✅ Análise completa de dados de coancestralidade")
    print("   ✅ Otimização usando meta-heurística GRASPE")
    print("   ✅ Interface web interativa")
    print("   ✅ Gráficos e relatórios detalhados")
    print("   ✅ Downloads de resultados")
    print()
    print("=" * 70)
    
    # Verificar Python
    python_version = sys.version_info
    if python_version.major < 3 or (python_version.major == 3 and python_version.minor < 7):
        print("❌ Python 3.7+ é necessário")
        print(f"🐍 Versão atual: Python {python_version.major}.{python_version.minor}")
        input("Pressione Enter para sair...")
        return
    
    print(f"🐍 Python {python_version.major}.{python_version.minor} detectado ✅")
    
    # Verificar dependências
    if not verificar_dependencias():
        print("❌ Falha na verificação de dependências")
        input("Pressione Enter para sair...")
        return
    
    print("\n✅ Todas as dependências estão prontas!")
    print()
    print("🔄 Iniciando sistema...")
    print("📱 O navegador será aberto automaticamente em http://localhost:8501")
    print("⏹️ Para parar: Pressione Ctrl+C")
    print()
    print("=" * 70)
    
    # Iniciar thread para abrir navegador
    browser_thread = Thread(target=abrir_navegador)
    browser_thread.daemon = True
    browser_thread.start()
    
    # Executar aplicação
    sucesso = executar_streamlit()
    
    if not sucesso:
        print("\n❌ Erro na execução")
        input("Pressione Enter para sair...")

if __name__ == "__main__":
    main()