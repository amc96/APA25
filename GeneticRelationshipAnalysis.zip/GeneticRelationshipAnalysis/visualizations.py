import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np
from typing import Dict, List

def create_statistics_comparison(original_stats: Dict, optimized_stats: Dict) -> go.Figure:
    """Create comparison chart between original and optimized statistics"""
    
    categories = ['Mínimo', 'Máximo', 'Média', 'Desvio Padrão']
    original_values = [
        original_stats['min'],
        original_stats['max'],
        original_stats['mean'],
        original_stats['std']
    ]
    optimized_values = [
        optimized_stats['min'],
        optimized_stats['max'],
        optimized_stats['mean'],
        optimized_stats['std']
    ]
    
    fig = go.Figure(data=[
        go.Bar(
            name='Original',
            x=categories,
            y=original_values,
            marker_color='lightcoral'
        ),
        go.Bar(
            name='Otimizado',
            x=categories,
            y=optimized_values,
            marker_color='lightblue'
        )
    ])
    
    fig.update_layout(
        title="Comparação: Estatísticas Original vs Otimizado",
        xaxis_title="Estatística",
        yaxis_title="Valor",
        barmode='group',
        template='plotly_white'
    )
    
    return fig

def create_convergence_analysis(results_df: pd.DataFrame) -> go.Figure:
    """Create convergence analysis plot"""
    
    fig = go.Figure()
    
    # Plot individual runs
    for run in results_df['run'].unique():
        run_data = results_df[results_df['run'] == run]
        fig.add_trace(go.Scatter(
            x=run_data['iteration'],
            y=run_data['cost'],
            mode='lines',
            name=f'Execução {run}',
            opacity=0.7,
            line=dict(width=1)
        ))
    
    # Add average line
    avg_by_iteration = results_df.groupby('iteration')['cost'].mean()
    fig.add_trace(go.Scatter(
        x=avg_by_iteration.index,
        y=avg_by_iteration.values,
        mode='lines+markers',
        name='Média',
        line=dict(color='red', width=3),
        marker=dict(size=6)
    ))
    
    fig.update_layout(
        title="Análise de Convergência do GRASP",
        xaxis_title="Iteração",
        yaxis_title="Custo (Coancestralidade Total)",
        template='plotly_white',
        hovermode='x unified'
    )
    
    return fig

def create_cost_distribution_plot(results_df: pd.DataFrame) -> go.Figure:
    """Create cost distribution histogram"""
    
    fig = px.histogram(
        results_df,
        x='cost',
        nbins=30,
        title="Distribuição dos Custos Encontrados",
        labels={'cost': 'Custo', 'count': 'Frequência'},
        template='plotly_white'
    )
    
    # Add statistical markers
    mean_cost = results_df['cost'].mean()
    median_cost = results_df['cost'].median()
    
    fig.add_vline(
        x=mean_cost,
        line_dash="dash",
        line_color="red",
        annotation_text=f"Média: {mean_cost:.6f}",
        annotation_position="top right"
    )
    
    fig.add_vline(
        x=median_cost,
        line_dash="dot",
        line_color="blue",
        annotation_text=f"Mediana: {median_cost:.6f}",
        annotation_position="top left"
    )
    
    return fig

def create_performance_metrics(results_df: pd.DataFrame) -> go.Figure:
    """Create performance metrics visualization"""
    
    runs_summary = results_df.groupby('run')['cost'].agg([
        'min', 'max', 'mean', 'std'
    ]).reset_index()
    
    fig = go.Figure()
    
    # Box plot for each run
    for run in results_df['run'].unique():
        run_data = results_df[results_df['run'] == run]['cost']
        fig.add_trace(go.Box(
            y=run_data,
            name=f'Execução {run}',
            boxpoints='outliers'
        ))
    
    fig.update_layout(
        title="Distribuição de Custos por Execução",
        yaxis_title="Custo",
        xaxis_title="Execução",
        template='plotly_white'
    )
    
    return fig

def create_improvement_analysis(original_mean: float, results_df: pd.DataFrame) -> go.Figure:
    """Create improvement analysis chart"""
    
    # Calculate improvement percentages
    improvements = []
    for _, row in results_df.iterrows():
        improvement = ((original_mean - row['cost']) / original_mean) * 100
        improvements.append(improvement)
    
    results_df_copy = results_df.copy()
    results_df_copy['improvement'] = improvements
    
    fig = px.scatter(
        results_df_copy,
        x='iteration',
        y='improvement',
        color='run',
        title="Melhoria Percentual por Iteração",
        labels={
            'improvement': 'Melhoria (%)',
            'iteration': 'Iteração',
            'run': 'Execução'
        },
        template='plotly_white'
    )
    
    # Add zero line
    fig.add_hline(
        y=0,
        line_dash="dash",
        line_color="gray",
        annotation_text="Sem melhoria"
    )
    
    return fig

def create_solution_heatmap(solution_matrix: np.ndarray, females: List[str], males: List[str]) -> go.Figure:
    """Create heatmap visualization of the solution"""
    
    fig = go.Figure(data=go.Heatmap(
        z=solution_matrix,
        x=[f"M{i+1}" for i in range(len(males))],
        y=[f"F{i+1}" for i in range(len(females))],
        colorscale='Viridis',
        showscale=True
    ))
    
    fig.update_layout(
        title="Matriz de Solução (Acasalamentos)",
        xaxis_title="Machos",
        yaxis_title="Fêmeas",
        template='plotly_white'
    )
    
    return fig

def create_male_utilization_chart(solution: List[int], num_males: int) -> go.Figure:
    """Create chart showing male utilization"""
    
    # Count how many times each male is used
    male_counts = [0] * num_males
    for male_idx in solution:
        if 0 <= male_idx < num_males:
            male_counts[male_idx] += 1
    
    male_names = [f"M{i+1}" for i in range(num_males)]
    
    fig = go.Figure(data=[
        go.Bar(
            x=male_names,
            y=male_counts,
            marker_color='lightgreen'
        )
    ])
    
    fig.update_layout(
        title="Utilização dos Machos na Melhor Solução",
        xaxis_title="Macho",
        yaxis_title="Número de Acasalamentos",
        template='plotly_white'
    )
    
    return fig
