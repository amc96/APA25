#!/usr/bin/env python3
"""
Script para instalar todas as dependências necessárias
Execute este arquivo antes de usar o sistema pela primeira vez
"""

import subprocess
import sys
import os

def instalar_pip():
    """Tentar instalar pip se não estiver disponível"""
    try:
        import pip
        return True
    except ImportError:
        print("📦 pip não encontrado, tentando instalar...")
        try:
            import ensurepip
            ensurepip.bootstrap()
            return True
        except:
            print("❌ Não foi possível instalar pip automaticamente")
            print("🔗 Visite: https://pip.pypa.io/en/stable/installation/")
            return False

def verificar_python():
    """Verificar versão do Python"""
    version = sys.version_info
    print(f"🐍 Python {version.major}.{version.minor}.{version.micro} detectado")
    
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        print("❌ ERRO: Python 3.7 ou superior é necessário")
        print("🔗 Baixe em: https://www.python.org/downloads/")
        return False
    
    print("✅ Versão do Python compatível")
    return True

def instalar_dependencia(nome_pacote):
    """Instalar uma dependência específica"""
    try:
        print(f"📦 Instalando {nome_pacote}...")
        resultado = subprocess.run(
            [sys.executable, '-m', 'pip', 'install', nome_pacote, '--user'],
            capture_output=True,
            text=True,
            timeout=300  # 5 minutos timeout
        )
        
        if resultado.returncode == 0:
            print(f"✅ {nome_pacote} instalado com sucesso")
            return True
        else:
            print(f"❌ Erro ao instalar {nome_pacote}:")
            print(resultado.stderr)
            return False
            
    except subprocess.TimeoutExpired:
        print(f"⏰ Timeout ao instalar {nome_pacote}")
        return False
    except Exception as e:
        print(f"❌ Erro inesperado ao instalar {nome_pacote}: {e}")
        return False

def main():
    """Função principal"""
    print("=" * 70)
    print("🔧 INSTALADOR DE DEPENDÊNCIAS - SISTEMA ACASALAMENTO ANIMAL")
    print("=" * 70)
    print()
    
    # Verificar Python
    if not verificar_python():
        input("Pressione Enter para sair...")
        return
    
    # Verificar pip
    if not instalar_pip():
        input("Pressione Enter para sair...")
        return
    
    print("✅ pip disponível")
    print()
    
    # Lista de dependências necessárias
    dependencias = [
        'streamlit',
        'pandas',
        'numpy', 
        'plotly',
        'matplotlib'  # Para compatibilidade
    ]
    
    print("📋 Dependências que serão instaladas:")
    for dep in dependencias:
        print(f"   📦 {dep}")
    print()
    
    # Confirmar instalação
    resposta = input("🤔 Continuar com a instalação? (s/n): ").lower().strip()
    if resposta not in ['s', 'sim', 'y', 'yes']:
        print("❌ Instalação cancelada pelo usuário")
        input("Pressione Enter para sair...")
        return
    
    print()
    print("🚀 Iniciando instalação...")
    print("⏰ Isso pode levar alguns minutos...")
    print()
    
    # Instalar cada dependência
    sucesso_total = True
    for dependencia in dependencias:
        sucesso = instalar_dependencia(dependencia)
        if not sucesso:
            sucesso_total = False
        print()  # Linha em branco
    
    print("=" * 70)
    if sucesso_total:
        print("🎉 INSTALAÇÃO CONCLUÍDA COM SUCESSO!")
        print()
        print("✅ Todas as dependências foram instaladas")
        print("🚀 Agora você pode executar o sistema:")
        print("   📁 Windows: Clique em EXECUTAR_SISTEMA.bat")
        print("   🐧 Linux/Mac: Execute ./EXECUTAR_SISTEMA.sh")
        print("   💻 Manual: python executavel_simples.py")
    else:
        print("⚠️ INSTALAÇÃO CONCLUÍDA COM PROBLEMAS")
        print()
        print("❌ Algumas dependências falharam")
        print("🔧 Tente executar manualmente:")
        print("   pip install streamlit pandas numpy plotly matplotlib")
    
    print("=" * 70)
    input("Pressione Enter para sair...")

if __name__ == "__main__":
    main()