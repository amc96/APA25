#!/usr/bin/env python3
"""
Sistema de Otimização de Acasalamento Animal - GRASPE
Executável principal para distribuição standalone
"""

import os
import sys
import subprocess
import webbrowser
import time
from threading import Thread
import tempfile
import shutil

def get_resource_path(relative_path):
    """Obter caminho do recurso, funciona tanto para desenvolvimento quanto para executável"""
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    
    return os.path.join(base_path, relative_path)

def setup_environment():
    """Configurar ambiente para execução"""
    # Definir variáveis de ambiente necessárias
    os.environ['STREAMLIT_SERVER_HEADLESS'] = 'true'
    os.environ['STREAMLIT_SERVER_PORT'] = '8501'
    os.environ['STREAMLIT_SERVER_ADDRESS'] = 'localhost'
    os.environ['STREAMLIT_BROWSER_GATHER_USAGE_STATS'] = 'false'

def run_streamlit_app():
    """Executar aplicação Streamlit"""
    app_path = get_resource_path('app.py')
    
    cmd = [
        sys.executable, '-m', 'streamlit', 'run', 
        app_path,
        '--server.port=8501',
        '--server.address=localhost',
        '--server.headless=true',
        '--browser.gatherUsageStats=false'
    ]
    
    try:
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Erro ao executar Streamlit: {e}")
        input("Pressione Enter para sair...")

def open_browser():
    """Abrir navegador automaticamente após delay"""
    time.sleep(3)  # Aguardar Streamlit inicializar
    webbrowser.open('http://localhost:8501')

def main():
    """Função principal do executável"""
    print("=" * 60)
    print("🐄 Sistema de Otimização de Acasalamento Animal - GRASPE")
    print("=" * 60)
    print()
    print("Iniciando aplicação...")
    print("O navegador será aberto automaticamente em http://localhost:8501")
    print()
    print("Para parar a aplicação, pressione Ctrl+C")
    print("=" * 60)
    
    # Configurar ambiente
    setup_environment()
    
    # Iniciar thread para abrir navegador
    browser_thread = Thread(target=open_browser)
    browser_thread.daemon = True
    browser_thread.start()
    
    # Executar aplicação Streamlit
    try:
        run_streamlit_app()
    except KeyboardInterrupt:
        print("\n\nAplicação encerrada pelo usuário.")
    except Exception as e:
        print(f"\nErro na execução: {e}")
        input("Pressione Enter para sair...")

if __name__ == "__main__":
    main()